function u = GetRobotControl()

u = [0; 1 ; 3*pi/180];