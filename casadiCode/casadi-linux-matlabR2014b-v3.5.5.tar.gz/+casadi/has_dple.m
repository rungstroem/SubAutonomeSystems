function varargout = has_dple(varargin)
    %HAS_DPLE Check if a particular plugin is available.
    %
    %  bool = HAS_DPLE(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(846, varargin{:});
end
