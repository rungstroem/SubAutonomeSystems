function varargout = has_rootfinder(varargin)
    %HAS_ROOTFINDER Check if a particular plugin is available.
    %
    %  bool = HAS_ROOTFINDER(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(821, varargin{:});
end
