function varargout = load_rootfinder(varargin)
    %LOAD_ROOTFINDER Explicitly load a plugin dynamically.
    %
    %  LOAD_ROOTFINDER(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(822, varargin{:});
end
