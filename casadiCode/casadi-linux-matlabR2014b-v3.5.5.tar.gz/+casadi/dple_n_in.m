function varargout = dple_n_in(varargin)
    %DPLE_N_IN Get the number of QP solver inputs.
    %
    %  int = DPLE_N_IN()
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(844, varargin{:});
end
