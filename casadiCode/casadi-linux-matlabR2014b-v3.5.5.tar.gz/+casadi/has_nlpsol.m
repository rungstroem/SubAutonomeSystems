function varargout = has_nlpsol(varargin)
    %HAS_NLPSOL Check if a particular plugin is available.
    %
    %  bool = HAS_NLPSOL(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(810, varargin{:});
end
