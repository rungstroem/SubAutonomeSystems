function varargout = load_interpolant(varargin)
    %LOAD_INTERPOLANT Explicitly load a plugin dynamically.
    %
    %  LOAD_INTERPOLANT(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(857, varargin{:});
end
