function varargout = doc_interpolant(varargin)
    %DOC_INTERPOLANT Get the documentation string for a plugin.
    %
    %  char = DOC_INTERPOLANT(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(858, varargin{:});
end
