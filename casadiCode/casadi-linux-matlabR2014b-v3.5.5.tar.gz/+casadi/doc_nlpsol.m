function varargout = doc_nlpsol(varargin)
    %DOC_NLPSOL Get the documentation string for a plugin.
    %
    %  char = DOC_NLPSOL(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(812, varargin{:});
end
