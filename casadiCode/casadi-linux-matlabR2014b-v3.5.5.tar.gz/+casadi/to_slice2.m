function varargout = to_slice2(varargin)
    %TO_SLICE2 Construct nested slices from an index vector (requires is_slice2(v) to be
    %
    %  std::pair< casadi::Slice,casadi::Slice > = TO_SLICE2([int] v)
    %
    %true)
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(202, varargin{:});
end
